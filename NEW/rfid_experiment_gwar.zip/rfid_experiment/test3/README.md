
Description

test3 will build a larger “sensor deck” that adds more PN532 sensors (beyond the three used on test2), and will allow adjustable placement of those sensors (velcro?)

Make another panel of RFID tags with a larger spacing than the 4” spacing from test2.

Add some status LEDs so the sensor deck can be operated without communication with a PC, to allow easier exploration of sensor/tag layouts. It will still need USB power.

